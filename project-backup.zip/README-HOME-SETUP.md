# Dr. Handyman - Home Development Setup

This guide will walk you through setting up your development environment at home.

## Instructions

1.  **Clone Your Repository:**
    *   Open your terminal and clone your project from GitHub:
    ```bash
    git clone <your-repository-url>
    cd Dr.-Handyman
    ```
    *(Replace `<your-repository-url>` with your actual repository URL.)*

2.  **Unzip the Backup:**
    *   Move the `project-backup.zip` file into this cloned repository folder.
    *   Unzip it to restore all your configurations and environment files. If you're on Windows with PowerShell, you can use this command:
    ```powershell
    Expand-Archive -Path .\project-backup.zip -DestinationPath . -Force
    ```

3.  **Install Dependencies:**
    *   This project uses `pnpm` for package management. Run the following command in your terminal to install all necessary packages. This will create the `node_modules` directory.
    ```bash
    pnpm install
    ```

4.  **Run Database Migrations:**
    *   The project uses Prisma for database management. To set up your local database schema, run:
    ```bash
    npx prisma migrate dev
    ```
    *This will apply all existing migrations to your database.*

5.  **Start Developing!**
    *   Your environment is now a complete mirror of your work setup. You can start the development server with:
    ```bash
    pnpm dev
    ```

---
*This file was generated automatically to guide your home setup. You can delete it after you are set up.* 